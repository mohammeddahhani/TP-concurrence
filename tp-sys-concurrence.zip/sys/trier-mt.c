/*
 * Classement dans l'ordre alphab�tique des noms des fichiers contenus
 * dans un r�pertoire et ses sous-r�pertoires.
 *
 * Utilisation : trier <r�pertoire>
 *
 * Auteur : E. Chaput
 * Date   : 08/10/2000
 */
#include <stdio.h>
#include <stdlib.h>   /* malloc */
#include <string.h>
#include <pthread.h>
#include <tri-fichier.h>
#include <liste-noms-mt.h>

typedef void * (*ThreadMain)(void *);
pthread_t thRech, thTri;

int main(int argc, char * argv[])
{
   RechercheNomsFichiers   recherche;
   ListeTrieeNoms        * listeTriee;

   /* Initialisation de la structure de recherche */
   recherche.liste = creerListeNoms();

   /* Traitement des param�tres */
   if (argc == 2) {
      recherche.nomRepertoire = argv[1];
   } else {
      printf("Usage : %s <r�pertoire>\n", argv[0]);
      exit(1);
   }

   /* On remplit la liste */
   pthread_create(&thRech,NULL,(ThreadMain)chercherFichiers,&recherche);
   //chercherFichiers(&recherche);

   /* On trie */
   //listeTriee = trier(recherche.liste);
   pthread_create(&thTri,NULL,(ThreadMain)trier,recherche.liste);


   pthread_join(thRech,NULL);
   pthread_join(thTri, (void*)&listeTriee);

   /* On affiche la liste tri�e */
   afficherListeTrieeNoms(*listeTriee);

   return 0;
}
