#ifndef NOMS_DEF
#define NOMS_DEF

/*
 * Un nom est une cha�ne de caract�res.
 */
typedef char * Nom;

#endif
